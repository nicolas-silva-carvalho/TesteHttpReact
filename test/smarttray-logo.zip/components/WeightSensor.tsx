"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { View, Text, StyleSheet } from "react-native"

interface WeightSensorProps {
  onWeightChange: (weight: number) => void
  isActive: boolean
}

export const WeightSensor: React.FC<WeightSensorProps> = ({ onWeightChange, isActive }) => {
  const [weight, setWeight] = useState(0)

  useEffect(() => {
    if (isActive) {
      // Simular conexão com ESP32
      const interval = setInterval(() => {
        // Aqui você conectaria com o ESP32 via WiFi
        // const newWeight = await fetchWeightFromESP32();
        const variation = (Math.random() - 0.5) * 3
        const newWeight = Math.max(0, weight + variation)

        setWeight(newWeight)
        onWeightChange(newWeight)
      }, 200)

      return () => clearInterval(interval)
    }
  }, [isActive, weight, onWeightChange])

  return (
    <View style={styles.container}>
      <Text style={styles.status}>{isActive ? "Sensor Ativo" : "Sensor Inativo"}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 8,
    backgroundColor: "#F0FDF4",
    borderRadius: 4,
    alignItems: "center",
  },
  status: {
    fontSize: 12,
    color: "#059669",
    fontWeight: "500",
  },
})
