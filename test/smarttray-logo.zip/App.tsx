"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Animated,
  Dimensions,
  Alert,
} from "react-native"
import { LinearGradient } from "expo-linear-gradient"
import Icon from "react-native-vector-icons/Feather"

const { width, height } = Dimensions.get("window")

type Screen = "splash" | "weighing" | "nutrition" | "history" | "settings"
type FoodCategory = "protein" | "carbs" | "vegetables" | "fruits" | "dairy" | "other"

interface WeighingData {
  weight: number
  food: string
  category: FoodCategory
  calories: number
  protein: number
  carbs: number
  fat: number
  timestamp: Date
}

interface FoodItem {
  name: string
  emoji: string
  category: FoodCategory
  caloriesPer100g: number
  proteinPer100g: number
  carbsPer100g: number
  fatPer100g: number
}

const FOODS: FoodItem[] = [
  {
    name: "Arroz",
    emoji: "🍚",
    category: "carbs",
    caloriesPer100g: 130,
    proteinPer100g: 2.7,
    carbsPer100g: 28,
    fatPer100g: 0.3,
  },
  {
    name: "Frango",
    emoji: "🍗",
    category: "protein",
    caloriesPer100g: 165,
    proteinPer100g: 31,
    carbsPer100g: 0,
    fatPer100g: 3.6,
  },
  {
    name: "Brócolis",
    emoji: "🥦",
    category: "vegetables",
    caloriesPer100g: 34,
    proteinPer100g: 2.8,
    carbsPer100g: 7,
    fatPer100g: 0.4,
  },
  {
    name: "Maçã",
    emoji: "🍎",
    category: "fruits",
    caloriesPer100g: 52,
    proteinPer100g: 0.3,
    carbsPer100g: 14,
    fatPer100g: 0.2,
  },
  {
    name: "Feijão",
    emoji: "🫘",
    category: "protein",
    caloriesPer100g: 127,
    proteinPer100g: 9,
    carbsPer100g: 23,
    fatPer100g: 0.5,
  },
  {
    name: "Batata",
    emoji: "🥔",
    category: "carbs",
    caloriesPer100g: 77,
    proteinPer100g: 2,
    carbsPer100g: 17,
    fatPer100g: 0.1,
  },
]

export default function SmartTrayApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash")
  const [currentWeight, setCurrentWeight] = useState(0)
  const [isWeighing, setIsWeighing] = useState(false)
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null)
  const [batteryLevel, setBatteryLevel] = useState(92)
  const [isConnected, setIsConnected] = useState(true)
  const [dailyCalories, setDailyCalories] = useState(1247)
  const [dailyGoal] = useState(2000)
  const [weighingHistory, setWeighingHistory] = useState<WeighingData[]>([])

  const fadeAnim = new Animated.Value(0)
  const scaleAnim = new Animated.Value(0.8)

  // Simular peso em tempo real
  useEffect(() => {
    if (isWeighing) {
      const interval = setInterval(() => {
        setCurrentWeight((prev) => {
          const variation = (Math.random() - 0.5) * 2
          return Math.max(0, Math.min(500, prev + variation))
        })
      }, 100)
      return () => clearInterval(interval)
    }
  }, [isWeighing])

  // Animação da splash screen
  useEffect(() => {
    if (currentScreen === "splash") {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
      ]).start()
    }
  }, [currentScreen])

  const calculateNutrition = (food: FoodItem, weight: number) => {
    const factor = weight / 100
    return {
      calories: Math.round(food.caloriesPer100g * factor),
      protein: Math.round(food.proteinPer100g * factor * 10) / 10,
      carbs: Math.round(food.carbsPer100g * factor * 10) / 10,
      fat: Math.round(food.fatPer100g * factor * 10) / 10,
    }
  }

  const addToMeal = () => {
    if (selectedFood && currentWeight > 0) {
      const nutrition = calculateNutrition(selectedFood, currentWeight)
      const newEntry: WeighingData = {
        weight: currentWeight,
        food: selectedFood.name,
        category: selectedFood.category,
        calories: nutrition.calories,
        protein: nutrition.protein,
        carbs: nutrition.carbs,
        fat: nutrition.fat,
        timestamp: new Date(),
      }

      setWeighingHistory((prev) => [newEntry, ...prev])
      setDailyCalories((prev) => prev + nutrition.calories)
      setCurrentWeight(0)
      setSelectedFood(null)
      setIsWeighing(false)

      Alert.alert("Sucesso!", `${selectedFood.name} adicionado à sua refeição!`)
    }
  }

  // Splash Screen
  if (currentScreen === "splash") {
    return (
      <LinearGradient colors={["#059669", "#10B981", "#34D399"]} style={styles.splashContainer}>
        <StatusBar barStyle="light-content" />
        <Animated.View style={[styles.splashContent, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
          {/* Logo */}
          <View style={styles.logoContainer}>
            <View style={styles.logo}>
              <View style={styles.plate}>
                <View style={styles.sensor} />
              </View>
              <Text style={styles.logoWeight}>0.00g</Text>
            </View>
          </View>

          <View style={styles.titleContainer}>
            <Text style={styles.title}>
              Smart<Text style={styles.titleAccent}>Tray</Text>
            </Text>
            <Text style={styles.subtitle}>Pesagem Inteligente de Alimentos</Text>
            <Text style={styles.description}>Controle sua nutrição com precisão</Text>
          </View>

          <View style={styles.loadingContainer}>
            <View style={styles.loadingRow}>
              <Icon name="activity" size={20} color="#D1FAE5" />
              <Text style={styles.loadingText}>Conectando à balança...</Text>
            </View>
            <View style={styles.progressBar}>
              <Animated.View style={[styles.progressFill, { width: "85%" }]} />
            </View>
          </View>

          <TouchableOpacity style={styles.startButton} onPress={() => setCurrentScreen("weighing")}>
            <Text style={styles.startButtonText}>Começar a Pesar</Text>
          </TouchableOpacity>
        </Animated.View>
      </LinearGradient>
    )
  }

  // Header Component
  const Header = ({ title }: { title: string }) => (
    <LinearGradient colors={["#059669", "#10B981"]} style={styles.header}>
      <View style={styles.headerContent}>
        <View style={styles.headerLeft}>
          <Icon name="activity" size={24} color="#FED7AA" />
          <Text style={styles.headerTitle}>{title}</Text>
        </View>
        <View style={styles.headerRight}>
          <View style={styles.statusItem}>
            <Icon name="wifi" size={16} color={isConnected ? "#D1FAE5" : "#FCA5A5"} />
            <Text style={styles.statusText}>{isConnected ? "Online" : "Offline"}</Text>
          </View>
          <View style={styles.statusItem}>
            <Icon name="battery" size={16} color="#D1FAE5" />
            <Text style={styles.statusText}>{batteryLevel}%</Text>
          </View>
        </View>
      </View>
    </LinearGradient>
  )

  // Navigation Component
  const Navigation = () => (
    <View style={styles.navigation}>
      {[
        { screen: "weighing", icon: "activity", label: "Pesar" },
        { screen: "nutrition", icon: "heart", label: "Nutrição" },
        { screen: "history", icon: "clock", label: "Histórico" },
        { screen: "settings", icon: "settings", label: "Config" },
      ].map((item) => (
        <TouchableOpacity
          key={item.screen}
          style={[styles.navItem, currentScreen === item.screen && styles.navItemActive]}
          onPress={() => setCurrentScreen(item.screen as Screen)}
        >
          <Icon name={item.icon} size={20} color={currentScreen === item.screen ? "#059669" : "#6B7280"} />
          <Text style={[styles.navLabel, currentScreen === item.screen && styles.navLabelActive]}>{item.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  )

  // Weighing Screen
  if (currentScreen === "weighing") {
    const nutrition = selectedFood && currentWeight > 0 ? calculateNutrition(selectedFood, currentWeight) : null

    return (
      <SafeAreaView style={styles.container}>
        <Header title="SmartTray - Pesagem" />

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Display Principal de Peso */}
          <LinearGradient colors={["#059669", "#10B981"]} style={styles.weightDisplay}>
            <Icon name="activity" size={64} color="#FED7AA" />
            <Text style={styles.weightValue}>{currentWeight.toFixed(1)}</Text>
            <Text style={styles.weightUnit}>gramas</Text>

            <View style={styles.weightControls}>
              <TouchableOpacity
                style={[styles.controlButton, { backgroundColor: isWeighing ? "#EF4444" : "#F97316" }]}
                onPress={() => setIsWeighing(!isWeighing)}
              >
                <Text style={styles.controlButtonText}>{isWeighing ? "Parar" : "Iniciar"} Pesagem</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.resetButton} onPress={() => setCurrentWeight(0)}>
                <Icon name="rotate-ccw" size={16} color="#059669" />
                <Text style={styles.resetButtonText}>Zerar</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>

          {/* Seleção de Alimento */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="coffee" size={20} color="#374151" />
              <Text style={styles.cardTitle}>Que alimento você está pesando?</Text>
            </View>

            <View style={styles.foodGrid}>
              {FOODS.map((food, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.foodItem, selectedFood?.name === food.name && styles.foodItemSelected]}
                  onPress={() => setSelectedFood(food)}
                >
                  <Text style={styles.foodEmoji}>{food.emoji}</Text>
                  <Text style={styles.foodName}>{food.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Informações Nutricionais */}
          {nutrition && (
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Icon name="bar-chart" size={20} color="#374151" />
                <Text style={styles.cardTitle}>Informações Nutricionais</Text>
              </View>

              <View style={styles.nutritionGrid}>
                <View style={[styles.nutritionItem, { backgroundColor: "#FFF7ED" }]}>
                  <Text style={[styles.nutritionValue, { color: "#EA580C" }]}>{nutrition.calories}</Text>
                  <Text style={[styles.nutritionLabel, { color: "#C2410C" }]}>Calorias</Text>
                </View>

                <View style={[styles.nutritionItem, { backgroundColor: "#EFF6FF" }]}>
                  <Text style={[styles.nutritionValue, { color: "#2563EB" }]}>{nutrition.protein}g</Text>
                  <Text style={[styles.nutritionLabel, { color: "#1D4ED8" }]}>Proteína</Text>
                </View>

                <View style={[styles.nutritionItem, { backgroundColor: "#F0FDF4" }]}>
                  <Text style={[styles.nutritionValue, { color: "#16A34A" }]}>{nutrition.carbs}g</Text>
                  <Text style={[styles.nutritionLabel, { color: "#15803D" }]}>Carboidratos</Text>
                </View>

                <View style={[styles.nutritionItem, { backgroundColor: "#FAF5FF" }]}>
                  <Text style={[styles.nutritionValue, { color: "#9333EA" }]}>{nutrition.fat}g</Text>
                  <Text style={[styles.nutritionLabel, { color: "#7C3AED" }]}>Gordura</Text>
                </View>
              </View>

              <TouchableOpacity style={styles.addButton} onPress={addToMeal}>
                <Icon name="plus" size={20} color="#FFFFFF" />
                <Text style={styles.addButtonText}>Adicionar à Refeição</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Ações Rápidas */}
          <View style={styles.quickActions}>
            <TouchableOpacity style={styles.quickAction}>
              <Icon name="clock" size={24} color="#6B7280" />
              <Text style={styles.quickActionText}>Última Pesagem</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.quickAction}>
              <Icon name="target" size={24} color="#6B7280" />
              <Text style={styles.quickActionText}>Meta Diária</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        <Navigation />
      </SafeAreaView>
    )
  }

  // Nutrition Screen
  if (currentScreen === "nutrition") {
    const progressPercentage = (dailyCalories / dailyGoal) * 100

    return (
      <SafeAreaView style={styles.container}>
        <Header title="Nutrição Diária" />

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Meta Diária */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="target" size={20} color="#374151" />
              <Text style={styles.cardTitle}>Meta Diária</Text>
            </View>

            <View style={styles.goalContainer}>
              <Text style={styles.goalValue}>{dailyCalories}</Text>
              <Text style={styles.goalLabel}>de {dailyGoal} calorias</Text>

              <View style={styles.progressContainer}>
                <View style={styles.progressTrack}>
                  <View style={[styles.progressBar, { width: `${Math.min(progressPercentage, 100)}%` }]} />
                </View>
              </View>

              <Text style={styles.remainingText}>Restam {dailyGoal - dailyCalories} calorias para sua meta</Text>
            </View>
          </View>

          {/* Macronutrientes */}
          <View style={styles.macroGrid}>
            <LinearGradient colors={["#3B82F6", "#2563EB"]} style={styles.macroCard}>
              <Icon name="zap" size={32} color="#DBEAFE" />
              <Text style={styles.macroValue}>85g</Text>
              <Text style={styles.macroLabel}>Proteína</Text>
            </LinearGradient>

            <LinearGradient colors={["#F97316", "#EA580C"]} style={styles.macroCard}>
              <Icon name="layers" size={32} color="#FED7AA" />
              <Text style={styles.macroValue}>156g</Text>
              <Text style={styles.macroLabel}>Carboidratos</Text>
            </LinearGradient>

            <LinearGradient colors={["#8B5CF6", "#7C3AED"]} style={styles.macroCard}>
              <Icon name="droplet" size={32} color="#E9D5FF" />
              <Text style={styles.macroValue}>42g</Text>
              <Text style={styles.macroLabel}>Gordura</Text>
            </LinearGradient>
          </View>

          {/* Refeições do Dia */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="coffee" size={20} color="#374151" />
              <Text style={styles.cardTitle}>Refeições de Hoje</Text>
            </View>

            {[
              { meal: "Café da Manhã", time: "08:30", calories: 320, items: "Aveia, Banana, Leite" },
              { meal: "Almoço", time: "12:45", calories: 580, items: "Arroz, Frango, Brócolis" },
              { meal: "Lanche", time: "16:00", calories: 150, items: "Maçã, Castanhas" },
              { meal: "Jantar", time: "19:30", calories: 197, items: "Pesando agora..." },
            ].map((meal, index) => (
              <View key={index} style={styles.mealItem}>
                <View style={styles.mealInfo}>
                  <Text style={styles.mealName}>{meal.meal}</Text>
                  <Text style={styles.mealItems}>{meal.items}</Text>
                </View>
                <View style={styles.mealStats}>
                  <Text style={styles.mealCalories}>{meal.calories} cal</Text>
                  <Text style={styles.mealTime}>{meal.time}</Text>
                </View>
              </View>
            ))}
          </View>
        </ScrollView>

        <Navigation />
      </SafeAreaView>
    )
  }

  // History Screen
  if (currentScreen === "history") {
    return (
      <SafeAreaView style={styles.container}>
        <Header title="Histórico" />

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Estatísticas */}
          <View style={styles.statsGrid}>
            <LinearGradient colors={["#059669", "#10B981"]} style={styles.statCard}>
              <Icon name="activity" size={32} color="#D1FAE5" />
              <Text style={styles.statValue}>47</Text>
              <Text style={styles.statLabel}>Pesagens</Text>
            </LinearGradient>

            <LinearGradient colors={["#F97316", "#EA580C"]} style={styles.statCard}>
              <Icon name="trending-up" size={32} color="#FED7AA" />
              <Text style={styles.statValue}>1.847</Text>
              <Text style={styles.statLabel}>Média Cal/dia</Text>
            </LinearGradient>
          </View>

          {/* Gráfico Placeholder */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="bar-chart" size={20} color="#374151" />
              <Text style={styles.cardTitle}>Calorias dos Últimos 7 Dias</Text>
            </View>

            <View style={styles.chartContainer}>
              <View style={styles.chart}>
                {[1650, 1890, 2100, 1750, 1920, 2050, 1847].map((calories, index) => (
                  <View key={index} style={styles.chartColumn}>
                    <View style={[styles.chartBar, { height: `${(calories / 2200) * 100}%` }]} />
                    <Text style={styles.chartLabel}>{["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"][index]}</Text>
                  </View>
                ))}
              </View>
            </View>
          </View>

          {/* Histórico de Pesagens */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Icon name="clock" size={20} color="#374151" />
              <Text style={styles.cardTitle}>Pesagens Recentes</Text>
            </View>

            {weighingHistory.length > 0 ? (
              weighingHistory.slice(0, 5).map((item, index) => (
                <View key={index} style={styles.historyItem}>
                  <View style={styles.historyDot} />
                  <View style={styles.historyInfo}>
                    <Text style={styles.historyFood}>{item.food}</Text>
                    <Text style={styles.historyWeight}>{item.weight.toFixed(1)}g</Text>
                  </View>
                  <View style={styles.historyStats}>
                    <Text style={styles.historyCalories}>{item.calories} cal</Text>
                    <Text style={styles.historyTime}>
                      {item.timestamp.toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </Text>
                  </View>
                </View>
              ))
            ) : (
              <Text style={styles.emptyText}>Nenhuma pesagem registrada ainda</Text>
            )}
          </View>
        </ScrollView>

        <Navigation />
      </SafeAreaView>
    )
  }

  // Settings Screen
  if (currentScreen === "settings") {
    return (
      <SafeAreaView style={styles.container}>
        <Header title="Configurações" />

        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Profile */}
          <View style={styles.card}>
            <View style={styles.profileContainer}>
              <LinearGradient colors={["#059669", "#10B981"]} style={styles.profileAvatar}>
                <Icon name="user" size={32} color="#FFFFFF" />
              </LinearGradient>
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>Usuário SmartTray</Text>
                <Text style={styles.profileEmail}>Meta: 2000 cal/dia</Text>
              </View>
            </View>
          </View>

          {/* Configurações da Balança */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Configurações da Balança</Text>

            {[
              { icon: "activity", label: "Calibrar Balança" },
              { icon: "wifi", label: "Conexão WiFi" },
              { icon: "zap", label: "Modo de Economia" },
            ].map((item, index) => (
              <TouchableOpacity key={index} style={styles.settingItem}>
                <View style={styles.settingLeft}>
                  <Icon name={item.icon} size={20} color="#6B7280" />
                  <Text style={styles.settingLabel}>{item.label}</Text>
                </View>
                <Icon name="chevron-right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            ))}
          </View>

          {/* Configurações Nutricionais */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Configurações Nutricionais</Text>

            {[
              { icon: "target", label: "Meta Diária" },
              { icon: "heart", label: "Base de Alimentos" },
              { icon: "bar-chart", label: "Unidades de Medida" },
            ].map((item, index) => (
              <TouchableOpacity key={index} style={styles.settingItem}>
                <View style={styles.settingLeft}>
                  <Icon name={item.icon} size={20} color="#6B7280" />
                  <Text style={styles.settingLabel}>{item.label}</Text>
                </View>
                <Icon name="chevron-right" size={20} color="#9CA3AF" />
              </TouchableOpacity>
            ))}
          </View>

          {/* Informações do Sistema */}
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Informações do Sistema</Text>

            {[
              { label: "Versão do App", value: "2.1.0" },
              { label: "Firmware ESP32", value: "1.4.2" },
              { label: "Precisão da Balança", value: "±0.1g" },
              { label: "Última Calibração", value: "Ontem" },
            ].map((item, index) => (
              <View key={index} style={styles.infoItem}>
                <Text style={styles.infoLabel}>{item.label}</Text>
                <Text style={styles.infoValue}>{item.value}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity style={styles.logoutButton} onPress={() => setCurrentScreen("splash")}>
            <Text style={styles.logoutButtonText}>Sair do App</Text>
          </TouchableOpacity>
        </ScrollView>

        <Navigation />
      </SafeAreaView>
    )
  }

  return null
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F9FAFB",
  },

  // Splash Screen
  splashContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  splashContent: {
    alignItems: "center",
    width: "100%",
  },
  logoContainer: {
    marginBottom: 32,
  },
  logo: {
    width: 160,
    height: 160,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  plate: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "#FFFFFF",
    borderWidth: 3,
    borderColor: "#E5E7EB",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  sensor: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: "#10B981",
  },
  logoWeight: {
    position: "absolute",
    top: -20,
    backgroundColor: "#1F2937",
    color: "#10B981",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
    fontSize: 12,
    fontFamily: "monospace",
  },
  titleContainer: {
    alignItems: "center",
    marginBottom: 32,
  },
  title: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },
  titleAccent: {
    color: "#FED7AA",
  },
  subtitle: {
    fontSize: 18,
    color: "#D1FAE5",
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: "#A7F3D0",
  },
  loadingContainer: {
    alignItems: "center",
    marginBottom: 32,
    width: "100%",
  },
  loadingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  loadingText: {
    color: "#D1FAE5",
    marginLeft: 8,
  },
  progressBar: {
    width: 256,
    height: 8,
    backgroundColor: "#047857",
    borderRadius: 4,
  },
  progressFill: {
    height: "100%",
    backgroundColor: "#F97316",
    borderRadius: 4,
  },
  startButton: {
    backgroundColor: "#F97316",
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  startButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "600",
  },

  // Header
  header: {
    paddingTop: StatusBar.currentHeight || 0,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "bold",
    marginLeft: 12,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  statusItem: {
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 12,
  },
  statusText: {
    color: "#D1FAE5",
    fontSize: 12,
    marginLeft: 4,
  },

  // Content
  content: {
    flex: 1,
    padding: 16,
  },

  // Cards
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#374151",
    marginLeft: 8,
  },

  // Weight Display
  weightDisplay: {
    borderRadius: 12,
    padding: 32,
    alignItems: "center",
    marginBottom: 16,
  },
  weightValue: {
    fontSize: 64,
    fontWeight: "bold",
    color: "#FFFFFF",
    fontFamily: "monospace",
    marginVertical: 16,
  },
  weightUnit: {
    fontSize: 24,
    color: "#D1FAE5",
    marginBottom: 24,
  },
  weightControls: {
    flexDirection: "row",
    alignItems: "center",
  },
  controlButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginRight: 16,
  },
  controlButtonText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
  resetButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
  },
  resetButtonText: {
    color: "#059669",
    fontWeight: "600",
    marginLeft: 8,
  },

  // Food Grid
  foodGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  foodItem: {
    width: (width - 64) / 3,
    aspectRatio: 1,
    backgroundColor: "#F9FAFB",
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
    borderWidth: 2,
    borderColor: "transparent",
  },
  foodItemSelected: {
    borderColor: "#059669",
    backgroundColor: "#F0FDF4",
  },
  foodEmoji: {
    fontSize: 32,
    marginBottom: 8,
  },
  foodName: {
    fontSize: 12,
    color: "#374151",
    textAlign: "center",
  },

  // Nutrition Grid
  nutritionGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  nutritionItem: {
    width: (width - 80) / 2,
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 12,
  },
  nutritionValue: {
    fontSize: 24,
    fontWeight: "bold",
  },
  nutritionLabel: {
    fontSize: 12,
    marginTop: 4,
  },

  // Add Button
  addButton: {
    backgroundColor: "#059669",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    borderRadius: 8,
  },
  addButtonText: {
    color: "#FFFFFF",
    fontWeight: "600",
    marginLeft: 8,
  },

  // Quick Actions
  quickActions: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  quickAction: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    marginHorizontal: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  quickActionText: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 8,
    textAlign: "center",
  },

  // Goal Container
  goalContainer: {
    alignItems: "center",
  },
  goalValue: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#059669",
  },
  goalLabel: {
    fontSize: 16,
    color: "#6B7280",
    marginBottom: 16,
  },
  progressContainer: {
    width: "100%",
    marginBottom: 12,
  },
  progressTrack: {
    width: "100%",
    height: 16,
    backgroundColor: "#E5E7EB",
    borderRadius: 8,
  },
  remainingText: {
    fontSize: 14,
    color: "#6B7280",
  },

  // Macro Grid
  macroGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  macroCard: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    marginHorizontal: 4,
  },
  macroValue: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginVertical: 8,
  },
  macroLabel: {
    fontSize: 12,
    color: "#FFFFFF",
    opacity: 0.8,
  },

  // Meal Items
  mealItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: "#F9FAFB",
    borderRadius: 8,
    marginBottom: 8,
  },
  mealInfo: {
    flex: 1,
  },
  mealName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#374151",
  },
  mealItems: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 2,
  },
  mealStats: {
    alignItems: "flex-end",
  },
  mealCalories: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#059669",
  },
  mealTime: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 2,
  },

  // Stats Grid
  statsGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: "center",
    marginHorizontal: 4,
  },
  statValue: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginVertical: 8,
  },
  statLabel: {
    fontSize: 12,
    color: "#FFFFFF",
    opacity: 0.8,
  },

  // Chart
  chartContainer: {
    height: 160,
  },
  chart: {
    flex: 1,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-around",
    backgroundColor: "#F0FDF4",
    borderRadius: 8,
    padding: 16,
  },
  chartColumn: {
    alignItems: "center",
    flex: 1,
  },
  chartBar: {
    width: 16,
    backgroundColor: "#059669",
    borderRadius: 8,
    marginBottom: 8,
  },
  chartLabel: {
    fontSize: 10,
    color: "#6B7280",
  },

  // History Items
  historyItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#F3F4F6",
  },
  historyDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#059669",
    marginRight: 12,
  },
  historyInfo: {
    flex: 1,
  },
  historyFood: {
    fontSize: 16,
    fontWeight: "600",
    color: "#374151",
  },
  historyWeight: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 2,
  },
  historyStats: {
    alignItems: "flex-end",
  },
  historyCalories: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#F97316",
  },
  historyTime: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 2,
  },
  emptyText: {
    textAlign: "center",
    color: "#6B7280",
    fontStyle: "italic",
    paddingVertical: 24,
  },

  // Profile
  profileContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: "600",
    color: "#374151",
  },
  profileEmail: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 2,
  },

  // Settings
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 12,
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#F3F4F6",
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  settingLabel: {
    fontSize: 16,
    color: "#374151",
    marginLeft: 12,
  },
  infoItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: "#374151",
  },
  infoValue: {
    fontSize: 14,
    color: "#6B7280",
  },
  logoutButton: {
    backgroundColor: "#EF4444",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 16,
  },
  logoutButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "600",
  },

  // Navigation
  navigation: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  navItem: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 8,
  },
  navItemActive: {
    backgroundColor: "#F0FDF4",
    borderRadius: 8,
  },
  navLabel: {
    fontSize: 10,
    color: "#6B7280",
    marginTop: 4,
  },
  navLabelActive: {
    color: "#059669",
    fontWeight: "600",
  },
})
