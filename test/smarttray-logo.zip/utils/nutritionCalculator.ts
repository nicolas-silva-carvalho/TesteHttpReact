export interface NutritionData {
  calories: number
  protein: number
  carbs: number
  fat: number
  fiber?: number
  sugar?: number
}

export interface FoodDatabase {
  [key: string]: {
    name: string
    nutritionPer100g: NutritionData
    category: "protein" | "carbs" | "vegetables" | "fruits" | "dairy" | "other"
  }
}

export const FOOD_DATABASE: FoodDatabase = {
  arroz: {
    name: "Arroz Branco",
    nutritionPer100g: {
      calories: 130,
      protein: 2.7,
      carbs: 28,
      fat: 0.3,
      fiber: 0.4,
    },
    category: "carbs",
  },
  frango: {
    name: "Peito de Frango",
    nutritionPer100g: {
      calories: 165,
      protein: 31,
      carbs: 0,
      fat: 3.6,
    },
    category: "protein",
  },
  brocolis: {
    name: "Brócolis",
    nutritionPer100g: {
      calories: 34,
      protein: 2.8,
      carbs: 7,
      fat: 0.4,
      fiber: 2.6,
    },
    category: "vegetables",
  },
  maca: {
    name: "Maçã",
    nutritionPer100g: {
      calories: 52,
      protein: 0.3,
      carbs: 14,
      fat: 0.2,
      fiber: 2.4,
      sugar: 10,
    },
    category: "fruits",
  },
  feijao: {
    name: "Feijão Carioca",
    nutritionPer100g: {
      calories: 127,
      protein: 9,
      carbs: 23,
      fat: 0.5,
      fiber: 9,
    },
    category: "protein",
  },
  batata: {
    name: "Batata",
    nutritionPer100g: {
      calories: 77,
      protein: 2,
      carbs: 17,
      fat: 0.1,
      fiber: 2.2,
    },
    category: "carbs",
  },
}

export const calculateNutrition = (foodKey: string, weightInGrams: number): NutritionData | null => {
  const food = FOOD_DATABASE[foodKey.toLowerCase()]
  if (!food) return null

  const factor = weightInGrams / 100

  return {
    calories: Math.round(food.nutritionPer100g.calories * factor),
    protein: Math.round(food.nutritionPer100g.protein * factor * 10) / 10,
    carbs: Math.round(food.nutritionPer100g.carbs * factor * 10) / 10,
    fat: Math.round(food.nutritionPer100g.fat * factor * 10) / 10,
    fiber: food.nutritionPer100g.fiber ? Math.round(food.nutritionPer100g.fiber * factor * 10) / 10 : undefined,
    sugar: food.nutritionPer100g.sugar ? Math.round(food.nutritionPer100g.sugar * factor * 10) / 10 : undefined,
  }
}

export const getDailyRecommendations = (
  age: number,
  gender: "male" | "female",
  activityLevel: "sedentary" | "light" | "moderate" | "active" | "very_active",
  weight: number,
  height: number,
) => {
  // Cálculo básico de TMB (Taxa Metabólica Basal)
  let bmr: number

  if (gender === "male") {
    bmr = 88.362 + 13.397 * weight + 4.799 * height - 5.677 * age
  } else {
    bmr = 447.593 + 9.247 * weight + 3.098 * height - 4.33 * age
  }

  // Fatores de atividade
  const activityFactors = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9,
  }

  const dailyCalories = Math.round(bmr * activityFactors[activityLevel])

  return {
    calories: dailyCalories,
    protein: Math.round(weight * 1.2), // 1.2g por kg de peso
    carbs: Math.round((dailyCalories * 0.5) / 4), // 50% das calorias
    fat: Math.round((dailyCalories * 0.25) / 9), // 25% das calorias
  }
}
