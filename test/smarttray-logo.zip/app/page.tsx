"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  Scale,
  Apple,
  Utensils,
  TrendingUp,
  Settings,
  History,
  Plus,
  RotateCcw,
  Wifi,
  Battery,
  Clock,
  Target,
  Award,
  ChefHat,
  Beef,
  Wheat,
  Droplets,
  Zap,
  User,
  ChevronRight,
  Menu,
  X,
  Calculator,
} from "lucide-react"

type Screen = "splash" | "weighing" | "nutrition" | "history" | "settings"
type FoodCategory = "protein" | "carbs" | "vegetables" | "fruits" | "dairy" | "other"

interface WeighingData {
  weight: number
  food: string
  category: FoodCategory
  calories: number
  protein: number
  carbs: number
  fat: number
  timestamp: Date
}

export default function SmartTrayApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash")
  const [currentWeight, setCurrentWeight] = useState(0)
  const [isWeighing, setIsWeighing] = useState(false)
  const [selectedFood, setSelectedFood] = useState("")
  const [batteryLevel, setBatteryLevel] = useState(92)
  const [isConnected, setIsConnected] = useState(true)
  const [dailyCalories, setDailyCalories] = useState(1247)
  const [dailyGoal] = useState(2000)
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  // Simular peso em tempo real
  useEffect(() => {
    if (isWeighing) {
      const interval = setInterval(() => {
        setCurrentWeight((prev) => {
          const variation = (Math.random() - 0.5) * 2
          return Math.max(0, prev + variation)
        })
      }, 100)
      return () => clearInterval(interval)
    }
  }, [isWeighing])

  // Splash Screen com nova logo
  if (currentScreen === "splash") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-600 via-green-600 to-teal-700 flex flex-col items-center justify-center p-6">
        <div className="text-center space-y-8">
          {/* Nova Logo para Pesagem de Alimentos */}
          <div className="relative">
            <div className="w-40 h-40 mx-auto mb-6 relative">
              <svg width="160" height="160" viewBox="0 0 200 200" className="w-full h-full drop-shadow-2xl">
                <defs>
                  <linearGradient id="plateGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#FFFFFF" />
                    <stop offset="100%" stopColor="#F3F4F6" />
                  </linearGradient>
                  <linearGradient id="baseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#1F2937" />
                    <stop offset="100%" stopColor="#374151" />
                  </linearGradient>
                  <linearGradient id="scaleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>

                {/* Base da Bandeja */}
                <ellipse cx="100" cy="160" rx="80" ry="20" fill="url(#baseGradient)" />
                <rect x="20" y="140" width="160" height="20" rx="10" fill="url(#baseGradient)" />

                {/* Prato Central */}
                <circle cx="100" cy="100" r="60" fill="url(#plateGradient)" stroke="#E5E7EB" strokeWidth="3" />
                <circle cx="100" cy="100" r="50" fill="none" stroke="#F3F4F6" strokeWidth="2" />

                {/* Sensor de Peso (centro) */}
                <circle cx="100" cy="100" r="8" fill="url(#scaleGradient)" />
                <circle cx="100" cy="100" r="4" fill="#FFFFFF" className="animate-pulse" />

                {/* Indicadores de Peso */}
                <g stroke="url(#scaleGradient)" strokeWidth="2" fill="none">
                  <path d="M100 40 L100 50" />
                  <path d="M100 150 L100 160" />
                  <path d="M40 100 L50 100" />
                  <path d="M150 100 L160 100" />
                  <path d="M65 65 L71 71" />
                  <path d="M135 135 L129 129" />
                  <path d="M135 65 L129 71" />
                  <path d="M65 135 L71 129" />
                </g>

                {/* Display Digital */}
                <rect x="70" y="20" width="60" height="20" rx="5" fill="#1F2937" />
                <text x="100" y="33" textAnchor="middle" fill="#10B981" fontSize="10" fontFamily="monospace">
                  0.00g
                </text>

                {/* Alimento Exemplo */}
                <circle cx="90" cy="90" r="12" fill="#EF4444" opacity="0.8" />
                <circle cx="110" cy="95" r="8" fill="#F59E0B" opacity="0.8" />
                <circle cx="105" cy="85" r="6" fill="#10B981" opacity="0.8" />
              </svg>
            </div>
          </div>

          <div>
            <h1 className="text-5xl font-bold text-white mb-2">
              Smart<span className="text-orange-300">Tray</span>
            </h1>
            <p className="text-green-200 text-lg">Pesagem Inteligente de Alimentos</p>
            <p className="text-green-300 text-sm mt-1">Controle sua nutrição com precisão</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-center space-x-2 text-green-200">
              <Scale className="w-5 h-5 animate-bounce" />
              <span>Conectando à balança...</span>
            </div>
            <div className="w-64 bg-green-800 rounded-full h-2">
              <div className="bg-orange-400 h-2 rounded-full animate-pulse" style={{ width: "85%" }}></div>
            </div>
          </div>

          <Button
            onClick={() => setCurrentScreen("weighing")}
            className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-full text-lg font-semibold shadow-lg"
          >
            Começar a Pesar
          </Button>
        </div>
      </div>
    )
  }

  // Header Component
  const Header = ({ title }: { title: string }) => (
    <div className="bg-gradient-to-r from-emerald-600 to-green-600 text-white p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Scale className="w-8 h-8 text-orange-300" />
          <h1 className="text-xl font-bold">{title}</h1>
        </div>
        <div className="flex items-center space-x-3">
          <div className={`flex items-center space-x-1 ${isConnected ? "text-green-300" : "text-red-300"}`}>
            <Wifi className="w-4 h-4" />
            <span className="text-sm">{isConnected ? "Online" : "Offline"}</span>
          </div>
          <div className="flex items-center space-x-1 text-green-300">
            <Battery className="w-4 h-4" />
            <span className="text-sm">{batteryLevel}%</span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>
    </div>
  )

  // Navigation Component
  const Navigation = () => (
    <div className="bg-white border-t border-gray-200 px-4 py-2">
      <div className="flex justify-around">
        <Button
          variant={currentScreen === "weighing" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentScreen("weighing")}
          className="flex flex-col items-center space-y-1 p-2"
        >
          <Scale className="w-5 h-5" />
          <span className="text-xs">Pesar</span>
        </Button>
        <Button
          variant={currentScreen === "nutrition" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentScreen("nutrition")}
          className="flex flex-col items-center space-y-1 p-2"
        >
          <Apple className="w-5 h-5" />
          <span className="text-xs">Nutrição</span>
        </Button>
        <Button
          variant={currentScreen === "history" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentScreen("history")}
          className="flex flex-col items-center space-y-1 p-2"
        >
          <History className="w-5 h-5" />
          <span className="text-xs">Histórico</span>
        </Button>
        <Button
          variant={currentScreen === "settings" ? "default" : "ghost"}
          size="sm"
          onClick={() => setCurrentScreen("settings")}
          className="flex flex-col items-center space-y-1 p-2"
        >
          <Settings className="w-5 h-5" />
          <span className="text-xs">Config</span>
        </Button>
      </div>
    </div>
  )

  // Weighing Screen (Principal)
  if (currentScreen === "weighing") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header title="SmartTray - Pesagem" />

        <div className="p-4 space-y-6">
          {/* Display Principal de Peso */}
          <Card className="bg-gradient-to-br from-emerald-500 to-green-600 text-white">
            <CardContent className="p-8 text-center">
              <div className="space-y-4">
                <Scale className="w-16 h-16 mx-auto text-orange-300" />
                <div>
                  <div className="text-6xl font-bold font-mono">{currentWeight.toFixed(1)}</div>
                  <div className="text-2xl text-green-100">gramas</div>
                </div>
                <div className="flex justify-center space-x-4">
                  <Button
                    onClick={() => setIsWeighing(!isWeighing)}
                    className={`${isWeighing ? "bg-red-500 hover:bg-red-600" : "bg-orange-500 hover:bg-orange-600"} text-white px-6 py-2`}
                  >
                    {isWeighing ? "Parar" : "Iniciar"} Pesagem
                  </Button>
                  <Button
                    onClick={() => setCurrentWeight(0)}
                    variant="outline"
                    className="bg-white text-green-600 border-white hover:bg-green-50"
                  >
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Zerar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Seleção de Alimento */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Utensils className="w-5 h-5" />
                <span>Que alimento você está pesando?</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-3 gap-3">
                {[
                  { name: "Arroz", icon: "🍚", category: "carbs" },
                  { name: "Frango", icon: "🍗", category: "protein" },
                  { name: "Brócolis", icon: "🥦", category: "vegetables" },
                  { name: "Maçã", icon: "🍎", category: "fruits" },
                  { name: "Feijão", icon: "🫘", category: "protein" },
                  { name: "Batata", icon: "🥔", category: "carbs" },
                ].map((food, index) => (
                  <Button
                    key={index}
                    variant={selectedFood === food.name ? "default" : "outline"}
                    className="h-20 flex flex-col space-y-1"
                    onClick={() => setSelectedFood(food.name)}
                  >
                    <span className="text-2xl">{food.icon}</span>
                    <span className="text-xs">{food.name}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Informações Nutricionais Rápidas */}
          {selectedFood && currentWeight > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calculator className="w-5 h-5" />
                  <span>Informações Nutricionais</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{Math.round((currentWeight / 100) * 130)}</div>
                    <div className="text-sm text-orange-700">Calorias</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{Math.round((currentWeight / 100) * 25)}g</div>
                    <div className="text-sm text-blue-700">Proteína</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{Math.round((currentWeight / 100) * 30)}g</div>
                    <div className="text-sm text-green-700">Carboidratos</div>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{Math.round((currentWeight / 100) * 5)}g</div>
                    <div className="text-sm text-purple-700">Gordura</div>
                  </div>
                </div>
                <Button className="w-full mt-4 bg-emerald-500 hover:bg-emerald-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar à Refeição
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Ações Rápidas */}
          <div className="grid grid-cols-2 gap-4">
            <Button variant="outline" className="h-16 flex flex-col space-y-1">
              <History className="w-6 h-6" />
              <span className="text-sm">Última Pesagem</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col space-y-1">
              <Target className="w-6 h-6" />
              <span className="text-sm">Meta Diária</span>
            </Button>
          </div>
        </div>

        <Navigation />
      </div>
    )
  }

  // Nutrition Screen
  if (currentScreen === "nutrition") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header title="Nutrição Diária" />

        <div className="p-4 space-y-6">
          {/* Progresso Diário */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="w-5 h-5" />
                <span>Meta Diária</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="text-center space-y-4">
                <div>
                  <div className="text-4xl font-bold text-emerald-600">{dailyCalories}</div>
                  <div className="text-gray-500">de {dailyGoal} calorias</div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-4">
                  <div
                    className="bg-gradient-to-r from-emerald-400 to-green-500 h-4 rounded-full transition-all duration-300"
                    style={{ width: `${(dailyCalories / dailyGoal) * 100}%` }}
                  ></div>
                </div>
                <div className="text-sm text-gray-600">Restam {dailyGoal - dailyCalories} calorias para sua meta</div>
              </div>
            </CardContent>
          </Card>

          {/* Macronutrientes */}
          <div className="grid grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-4 text-center">
                <Beef className="w-8 h-8 mx-auto mb-2 text-blue-200" />
                <div className="text-2xl font-bold">85g</div>
                <div className="text-blue-100 text-sm">Proteína</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-4 text-center">
                <Wheat className="w-8 h-8 mx-auto mb-2 text-orange-200" />
                <div className="text-2xl font-bold">156g</div>
                <div className="text-orange-100 text-sm">Carboidratos</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-4 text-center">
                <Droplets className="w-8 h-8 mx-auto mb-2 text-purple-200" />
                <div className="text-2xl font-bold">42g</div>
                <div className="text-purple-100 text-sm">Gordura</div>
              </CardContent>
            </Card>
          </div>

          {/* Refeições do Dia */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ChefHat className="w-5 h-5" />
                <span>Refeições de Hoje</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              {[
                { meal: "Café da Manhã", time: "08:30", calories: 320, items: "Aveia, Banana, Leite" },
                { meal: "Almoço", time: "12:45", calories: 580, items: "Arroz, Frango, Brócolis" },
                { meal: "Lanche", time: "16:00", calories: 150, items: "Maçã, Castanhas" },
                { meal: "Jantar", time: "19:30", calories: 197, items: "Pesando agora..." },
              ].map((meal, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-semibold">{meal.meal}</div>
                    <div className="text-sm text-gray-500">{meal.items}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-emerald-600">{meal.calories} cal</div>
                    <div className="text-xs text-gray-500">{meal.time}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Conquistas */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Award className="w-5 h-5" />
                <span>Conquistas</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center space-x-2 p-2 bg-yellow-50 rounded-lg">
                  <div className="text-2xl">🏆</div>
                  <div>
                    <div className="text-sm font-semibold">Meta Semanal</div>
                    <div className="text-xs text-gray-500">5/7 dias</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 p-2 bg-green-50 rounded-lg">
                  <div className="text-2xl">🥗</div>
                  <div>
                    <div className="text-sm font-semibold">Vegetais</div>
                    <div className="text-xs text-gray-500">Meta atingida</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Navigation />
      </div>
    )
  }

  // History Screen
  if (currentScreen === "history") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header title="Histórico" />

        <div className="p-4 space-y-6">
          {/* Estatísticas Semanais */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-gradient-to-br from-emerald-500 to-green-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm">Pesagens</p>
                    <p className="text-2xl font-bold">47</p>
                  </div>
                  <Scale className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm">Média Cal/dia</p>
                    <p className="text-2xl font-bold">1.847</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Gráfico de Calorias */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>Calorias dos Últimos 7 Dias</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="h-40 bg-gradient-to-t from-emerald-100 to-emerald-50 rounded-lg flex items-end justify-around p-4">
                {[1650, 1890, 2100, 1750, 1920, 2050, 1847].map((calories, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div
                      className="w-6 bg-emerald-500 rounded-t mb-2"
                      style={{ height: `${(calories / 2200) * 100}%` }}
                    ></div>
                    <span className="text-xs text-gray-500">
                      {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"][index]}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Histórico de Pesagens */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Pesagens Recentes</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                {[
                  { food: "Arroz Integral", weight: "120g", calories: 156, time: "19:45" },
                  { food: "Peito de Frango", weight: "150g", calories: 248, time: "19:42" },
                  { food: "Brócolis", weight: "80g", calories: 27, time: "19:40" },
                  { food: "Azeite", weight: "10g", calories: 90, time: "19:38" },
                  { food: "Maçã", weight: "180g", calories: 95, time: "16:15" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      <div>
                        <div className="font-semibold">{item.food}</div>
                        <div className="text-sm text-gray-500">{item.weight}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-orange-600">{item.calories} cal</div>
                      <div className="text-xs text-gray-500">{item.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Navigation />
      </div>
    )
  }

  // Settings Screen
  if (currentScreen === "settings") {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header title="Configurações" />

        <div className="p-4 space-y-6">
          {/* Profile */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Usuário SmartTray</h3>
                  <p className="text-gray-500">Meta: 2000 cal/dia</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Configurações da Balança */}
          <Card>
            <CardHeader>
              <CardTitle>Configurações da Balança</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Scale className="w-4 h-4" />
                  <span>Calibrar Balança</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Wifi className="w-4 h-4" />
                  <span>Conexão WiFi</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Zap className="w-4 h-4" />
                  <span>Modo de Economia</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>

          {/* Configurações Nutricionais */}
          <Card>
            <CardHeader>
              <CardTitle>Configurações Nutricionais</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4" />
                  <span>Meta Diária</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Apple className="w-4 h-4" />
                  <span>Base de Alimentos</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" className="w-full justify-between">
                <div className="flex items-center space-x-2">
                  <Calculator className="w-4 h-4" />
                  <span>Unidades de Medida</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>

          {/* Informações do Sistema */}
          <Card>
            <CardHeader>
              <CardTitle>Informações do Sistema</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              <div className="flex justify-between">
                <span>Versão do App</span>
                <span className="text-gray-500">2.1.0</span>
              </div>
              <div className="flex justify-between">
                <span>Firmware ESP32</span>
                <span className="text-gray-500">1.4.2</span>
              </div>
              <div className="flex justify-between">
                <span>Precisão da Balança</span>
                <span className="text-gray-500">±0.1g</span>
              </div>
              <div className="flex justify-between">
                <span>Última Calibração</span>
                <span className="text-gray-500">Ontem</span>
              </div>
            </CardContent>
          </Card>

          {/* Logout */}
          <Button variant="destructive" className="w-full" onClick={() => setCurrentScreen("splash")}>
            Sair do App
          </Button>
        </div>

        <Navigation />
      </div>
    )
  }

  return null
}
