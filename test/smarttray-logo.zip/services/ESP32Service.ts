export class ESP32Service {
  private baseUrl: string
  private isConnected = false

  constructor(esp32IpAddress = "192.168.1.100") {
    this.baseUrl = `http://${esp32IpAddress}`
  }

  async connect(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/status`, {
        method: "GET",
        timeout: 5000,
      })

      if (response.ok) {
        this.isConnected = true
        return true
      }
      return false
    } catch (error) {
      console.error("Erro ao conectar com ESP32:", error)
      this.isConnected = false
      return false
    }
  }

  async getWeight(): Promise<number | null> {
    if (!this.isConnected) {
      await this.connect()
    }

    try {
      const response = await fetch(`${this.baseUrl}/weight`, {
        method: "GET",
        timeout: 3000,
      })

      if (response.ok) {
        const data = await response.json()
        return data.weight || 0
      }
      return null
    } catch (error) {
      console.error("Erro ao obter peso:", error)
      return null
    }
  }

  async calibrate(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/calibrate`, {
        method: "POST",
        timeout: 10000,
      })

      return response.ok
    } catch (error) {
      console.error("Erro ao calibrar:", error)
      return false
    }
  }

  async tare(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/tare`, {
        method: "POST",
        timeout: 5000,
      })

      return response.ok
    } catch (error) {
      console.error("Erro ao zerar:", error)
      return false
    }
  }

  async getBatteryLevel(): Promise<number | null> {
    try {
      const response = await fetch(`${this.baseUrl}/battery`, {
        method: "GET",
        timeout: 3000,
      })

      if (response.ok) {
        const data = await response.json()
        return data.battery || 0
      }
      return null
    } catch (error) {
      console.error("Erro ao obter nível da bateria:", error)
      return null
    }
  }

  getConnectionStatus(): boolean {
    return this.isConnected
  }
}

export const esp32Service = new ESP32Service()
